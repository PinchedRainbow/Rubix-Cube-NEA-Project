package com.jawaadianinc.rubixcubesolver

import android.content.res.Configuration
import android.support.design.widget.NavigationView
import android.util.Log
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity

class CubeActivity : AppCompatActivity(), EditScrambleDialog.EditScrambleDialogListener {
    private val TEXT_SCRAMBLE = "text scramble"
    private val COLOR_INPUT = "color input"
    private var currentMode = TEXT_SCRAMBLE
    private var solutionFragment: TextSolutionFragment? = null
    private var toolbar: Toolbar? = null
    private var drawerToggle: ActionBarDrawerToggle? = null
    private var drawerLayout: DrawerLayout? = null
    private var drawerList: NavigationView? = null
    private var navDrawerTitles: Array<String>
    fun onBackPressed() {
        if (getFragmentManager().getBackStackEntryCount() > 0) {
            getFragmentManager().popBackStack()
        } else {
            super.onBackPressed()
        }
    }

    protected fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        toolbar = findViewById(R.id.toolbar) as Toolbar?
        setSupportActionBar(toolbar)
        navDrawerTitles = getResources().getStringArray(R.array.nav_drawer_items)
        drawerLayout = findViewById(R.id.drawer_layout) as DrawerLayout?
        drawerList = findViewById(R.id.left_drawer) as NavigationView?
        drawerToggle = ActionBarDrawerToggle(
            this, drawerLayout,
            toolbar, R.string.open_drawer, R.string.close_drawer
        )
        drawerLayout.addDrawerListener(drawerToggle)
        drawerList.setNavigationItemSelectedListener(DrawerClickListener())
        val intent: Intent = getIntent()
        if (intent != null) {
            val extras: Bundle = intent.getExtras()
            val args: Bundle? = if (extras != null) extras.getBundle(ALL_COLORS_INPUTTED) else null
            val inputType = if (args != null) args.getString(INITIAL_INPUT_TYPE) else " "
            if (inputType != null && inputType == CAMERA_INPUT) {
                Log.d("Starting Color Input", "true")
                val colorInputFragment = ColorInputFragment()
                if (args != null) {
                    colorInputFragment.setArguments(args)
                } else {
                    Log.d("Colors are null", "TRUE")
                }
                getSupportFragmentManager().beginTransaction()
                    .add(R.id.container, colorInputFragment, "Color Input Fragment")
                    .addToBackStack(null)
                    .commit()
                drawerList.setCheckedItem(R.id.color_input)
            } else {
                solutionFragment = TextSolutionFragment()
                getSupportFragmentManager().beginTransaction()
                    .add(R.id.container, solutionFragment, "Text Solution Fragment")
                    .addToBackStack(null)
                    .commit()
                drawerList.setCheckedItem(R.id.text_scramble)
            }
        }
        getSupportActionBar().setDisplayHomeAsUpEnabled(true)
        getSupportActionBar().setHomeButtonEnabled(true)
    }

    fun onDialogPositiveClick(dialog: DialogFragment?, scramble: String?) {
        solutionFragment.onDialogPositiveClick(dialog, scramble)
    }

    fun onDialogNegativeClick(dialog: DialogFragment?) {}

    /**
     * When using the ActionBarDrawerToggle, you must call it during
     * onPostCreate() and onConfigurationChanged()...
     */
    protected fun onPostCreate(savedInstanceState: Bundle?) {
        super.onPostCreate(savedInstanceState)
        // Sync the toggle state after onRestoreInstanceState has occurred.
        drawerToggle.syncState()
    }

    fun onConfigurationChanged(newConfig: Configuration?) {
        super.onConfigurationChanged(newConfig)
        // Pass any configuration change to the drawer toggle
        drawerToggle.onConfigurationChanged(newConfig)
    }

    private inner class DrawerClickListener : NavigationView.OnNavigationItemSelectedListener {
        fun onNavigationItemSelected(@NonNull item: MenuItem): Boolean {
            when (item.itemId) {
                R.id.text_scramble -> if (currentMode != TEXT_SCRAMBLE) {
                    getSupportFragmentManager().beginTransaction()
                        .replace(R.id.container, TextSolutionFragment(), "Text Solution Fragment")
                        .addToBackStack(null)
                        .commit()
                    currentMode = TEXT_SCRAMBLE
                    drawerLayout.closeDrawers()
                }
                R.id.color_input -> if (currentMode != COLOR_INPUT) {
                    getSupportFragmentManager().beginTransaction()
                        .replace(R.id.container, ColorInputFragment(), "Color Input Fragment")
                        .addToBackStack(null)
                        .commit()
                    currentMode = COLOR_INPUT
                    drawerLayout.closeDrawers()
                }
                R.id.camera_input -> if (currentMode != "Camera Input") {
                    val intent = Intent(getApplicationContext(), CaptureCubeActivity::class.java)
                    startActivity(intent)
                    currentMode = "Camera Input"
                    drawerList.setCheckedItem(R.id.color_input)
                    drawerLayout.closeDrawers()
                }
            }
            return true
        }
    }

    companion object {
        const val INITIAL_INPUT_TYPE = "initial input type"
        const val MANUAL_COLOR_INPUT = "manual color input"
        const val CAMERA_INPUT = "camera input"
        const val ALL_COLORS_INPUTTED = "all colors inputted"
        const val COLORS_INPUTTED_LEFT = "colors inputted left"
        const val COLORS_INPUTTED_UP = "colors inputted up"
        const val COLORS_INPUTTED_FRONT = "colors inputted front"
        const val COLORS_INPUTTED_BACK = "colors inputted back"
        const val COLORS_INPUTTED_RIGHT = "colors inputted right"
        const val COLORS_INPUTTED_DOWN = "colors inputted down"
    }
}